local g = vim.g
g.mkdp_browser = "firefox"
