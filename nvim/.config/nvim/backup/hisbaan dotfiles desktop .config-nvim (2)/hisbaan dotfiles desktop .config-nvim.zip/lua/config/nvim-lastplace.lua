require('nvim-lastplace').setup {}
