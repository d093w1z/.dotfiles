require('nvim-toggler').setup({
    -- remove_default_keybinds = true,
})
