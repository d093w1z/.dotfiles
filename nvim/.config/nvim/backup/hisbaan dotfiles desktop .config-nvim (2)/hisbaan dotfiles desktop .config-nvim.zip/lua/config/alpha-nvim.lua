require'alpha'.setup(require'alpha.themes.dashboard'.opts)
